import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import apiService from '../services/api';

function Register() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    
    try {
      setLoading(true);
      setError('');
      
      // Call the register API
      await apiService.register({
        name: formData.name,
        email: formData.email,
        password: formData.password
      });
      
      // Redirect to events page on successful registration
      navigate('/events');
    } catch (err) {
      setError(err.message || 'Registration failed');
      console.error('Registration error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card reverse-card">
        <div className="auth-form">
          <div className="form-header">
            <h2>CREATE ACCOUNT</h2>
            {error && <div className="alert alert-danger">{error}</div>}
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="row">
              <div className="col-12 mb-4">
                <label htmlFor="name" className="form-label">FULL NAME</label>
                <input 
                  type="text" 
                  className="form-control" 
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  disabled={loading}
                  required
                  placeholder="Enter your full name"
                />
              </div>
              
              <div className="col-12 mb-4">
                <label htmlFor="email" className="form-label">EMAIL</label>
                <input 
                  type="email" 
                  className="form-control" 
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  disabled={loading}
                  required
                  placeholder="Enter your email"
                />
              </div>
              
              <div className="col-md-6 mb-4">
                <label htmlFor="password" className="form-label">PASSWORD</label>
                <input 
                  type="password" 
                  className="form-control" 
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  disabled={loading}
                  required
                  placeholder="Choose a password"
                />
              </div>
              
              <div className="col-md-6 mb-4">
                <label htmlFor="confirmPassword" className="form-label">CONFIRM</label>
                <input 
                  type="password" 
                  className="form-control" 
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  disabled={loading}
                  required
                  placeholder="Confirm password"
                />
              </div>
            </div>
            
            <div className="d-grid gap-2 mb-4">
              <button 
                type="submit" 
                className="btn btn-primary btn-lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    REGISTERING...
                  </>
                ) : 'REGISTER'}
              </button>
            </div>
            
            <div className="text-center">
              <span className="account-text">Already have an account?</span>
              <Link to="/login" className="register-link ms-2">
                LOGIN NOW
              </Link>
            </div>
          </form>
        </div>
        
        <div className="auth-banner">
          <div className="banner-content">
            <h1>JOIN US TODAY</h1>
            <p>Create an account to discover and participate in exciting college events</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Register; 