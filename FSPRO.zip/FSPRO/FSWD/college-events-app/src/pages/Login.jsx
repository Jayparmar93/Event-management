import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import apiService from '../services/api';

function Login() {
  // State variables for form inputs and error message
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.email || !formData.password) {
      setError('Please enter both email and password');
      return;
    }
    
    try {
      setLoading(true);
      setError('');
      
      // Call the login API
      await apiService.login(formData);
      
      // Redirect to events page on successful login
      navigate('/events');
    } catch (err) {
      setError(err.message || 'Login failed');
      console.error('Login error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-banner">
          <div className="banner-content">
            <h1>WELCOME BACK</h1>
            <p>Sign in to access and manage your college events</p>
          </div>
        </div>
        
        <div className="auth-form">
          <div className="form-header">
            <h2>LOGIN</h2>
            {error && <div className="alert alert-danger">{error}</div>}
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="form-group mb-4">
              <label htmlFor="email" className="form-label">EMAIL</label>
              <input 
                type="email" 
                className="form-control" 
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                disabled={loading}
                required
                placeholder="Enter your email"
              />
            </div>
            
            <div className="form-group mb-4">
              <label htmlFor="password" className="form-label">PASSWORD</label>
              <input 
                type="password" 
                className="form-control" 
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                disabled={loading}
                required
                placeholder="Enter your password"
              />
            </div>
            
            <div className="text-end mb-4">
              <Link to="/forgot-password" className="forgot-link">
                Forgot Password?
              </Link>
            </div>
            
            <div className="d-grid gap-2 mb-4">
              <button 
                type="submit" 
                className="btn btn-primary btn-lg"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    LOGGING IN...
                  </>
                ) : 'LOGIN'}
              </button>
            </div>
            
            <div className="text-center">
              <span className="account-text">Don't have an account?</span>
              <Link to="/register" className="register-link ms-2">
                REGISTER NOW
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login; 