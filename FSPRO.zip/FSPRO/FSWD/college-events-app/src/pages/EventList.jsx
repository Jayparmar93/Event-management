import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import apiService from '../services/api';

function EventList() {
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const fetchEvents = async () => {
    try {
      setLoading(true);
      const { events: fetchedEvents } = await apiService.getEvents();
      setEvents(fetchedEvents);
      setError(null);
    } catch (err) {
      setError('Failed to load events: ' + err.message);
      console.error('Error fetching events:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  const filteredEvents = events.filter(event => 
    event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    event.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this event?')) {
      try {
        setLoading(true);
        await apiService.deleteEvent(id);
        fetchEvents();
      } catch (err) {
        setError('Failed to delete event: ' + err.message);
        console.error('Error deleting event:', err);
        setLoading(false);
      }
    }
  };

  const showEventDetails = (event) => {
    setSelectedEvent(event);
  };

  const closeEventDetails = () => {
    setSelectedEvent(null);
  };

  return (
    <div className="container">
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-5">
        <h2 className="mb-4 mb-md-0">COLLEGE EVENTS</h2>
        <div className="d-flex">
          <div className="me-3 flex-grow-1">
            <input
              type="text"
              className="form-control"
              placeholder="SEARCH EVENTS..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button 
            className="btn btn-primary" 
            onClick={() => navigate('/add-event')}
          >
            ADD EVENT
          </button>
        </div>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}
      
      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-warning" role="status"></div>
        </div>
      ) : (
        <>
          {filteredEvents.length === 0 ? (
            <div className="alert alert-info">NO EVENTS FOUND</div>
          ) : (
            <div className="row">
              {filteredEvents.map(event => (
                <div key={event.id} className="col-card">
                  <div className="card h-100">
                    <div className="card-img-container">
                      <img src={event.imageUrl} className="card-img-top" alt={event.title} />
                      <div className="card-img-overlay-type">
                        <span className="badge">{event.type}</span>
                      </div>
                    </div>
                    
                    <div className="card-body">
                      <h5 className="card-title">{event.title}</h5>
                      <p className="card-date">
                        <small>{event.date}</small>
                      </p>
                      
                      <div className="btn-group mt-3">
                        <button 
                          className="btn btn-info btn-sm" 
                          onClick={() => showEventDetails(event)}
                        >
                          VIEW
                        </button>
                        <button 
                          className="btn btn-warning btn-sm" 
                          onClick={() => navigate(`/edit-event/${event.id}`)}
                        >
                          EDIT
                        </button>
                        <button 
                          className="btn btn-danger btn-sm" 
                          onClick={() => handleDelete(event.id)}
                        >
                          DELETE
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {selectedEvent && (
        <div className="modal show d-block" tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{selectedEvent.title}</h5>
                <button type="button" className="btn-close btn-close-white" onClick={closeEventDetails}></button>
              </div>
              <div className="modal-body">
                <img src={selectedEvent.imageUrl} className="img-fluid mb-4" alt={selectedEvent.title} />
                <div className="event-details">
                  <div className="event-detail-item">
                    <span className="detail-label">TYPE</span>
                    <span className="detail-value">{selectedEvent.type}</span>
                  </div>
                  <div className="event-detail-item">
                    <span className="detail-label">DATE</span>
                    <span className="detail-value">{selectedEvent.date}</span>
                  </div>
                  <div className="event-detail-item">
                    <span className="detail-label">LOCATION</span>
                    <span className="detail-value">{selectedEvent.location}</span>
                  </div>
                  <div className="event-detail-item">
                    <span className="detail-label">DESCRIPTION</span>
                    <p className="detail-value">{selectedEvent.description}</p>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={closeEventDetails}>
                  CLOSE
                </button>
              </div>
            </div>
          </div>
          <div className="modal-backdrop show"></div>
        </div>
      )}
    </div>
  );
}

export default EventList;