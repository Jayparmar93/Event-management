import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';

import Login from './pages/Login';
import Register from './pages/Register';
import EventList from './pages/EventList';
import EventForm from './pages/EventForm';
import LocalStorageTest from './LocalStorageTest';

function App() {
  return (
    <Router>
      <div className="app">
        <Navbar />
        
        <main>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/" element={<Navigate to="/login" />} />
            <Route path="/storage-test" element={<LocalStorageTest />} />
            
            <Route element={<ProtectedRoute />}>
              <Route path="/events" element={<EventList />} />
              <Route path="/add-event" element={<EventForm />} />
              <Route path="/edit-event/:id" element={<EventForm />} />
            </Route>
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
