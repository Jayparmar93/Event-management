import { Link, useNavigate } from 'react-router-dom';

function Navbar() {
  const navigate = useNavigate();
  
  const user = JSON.parse(localStorage.getItem('user'));
  
  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };
  
  return (
    <nav className="navbar navbar-light">
      <div className="container">
        <Link className="navbar-brand" to="/">
          <span className="text-danger">COLLEGE</span>EVENT
        </Link>
        
        <div className="navbar-nav-container">
          <ul className="navbar-nav d-flex flex-row">
            {user ? (
              <>
                <li className="nav-item me-3">
                  <Link className="nav-link px-2" to="/events">EVENTS</Link>
                </li>
                <li className="nav-item me-3">
                  <Link className="nav-link px-2" to="/add-event">CREATE</Link>
                </li>
                <li className="nav-item me-3">
                  <span className="nav-link px-2">{user.name}</span>
                </li>
                <li className="nav-item">
                  <button className="btn px-2" onClick={handleLogout}>LOGOUT</button>
                </li>
              </>
            ) : (
              <>
                <li className="nav-item me-3">
                  <Link className="nav-link px-2" to="/login">LOGIN</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link px-2" to="/register">REGISTER</Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;